const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Расчёт финансовой модели
app.post('/calculate', (req, res) => {
  const data = req.body;
  
  // Базовые параметры
  const horizon = data.A?.horizon || 6;
  const startYear = 2026;
  const years = Array.from({ length: horizon }, (_, i) => startYear + i);
  
  // Продукты из раздела E
  const products = data.E || [];
  
  // Прямые затраты на единицу из C1
  const directCosts = data.C1 || [];
  
  // Косвенные производственные затраты из C2
  const indirectCosts = data.C2 || [];
  
  // АХР из D
  const adminCosts = data.D || [];
  
  // Персонал из F
  const personnel = data.F || [];
  
  // Инвестиции из B
  const investments = data.B || [];
  
  // Выручка и количество по годам
  let revenueByYear = {};
  let quantityByYear = {};
  
  years.forEach(year => {
    let yearRevenue = 0;
    let yearQuantity = 0;
    
    products.forEach(product => {
      const startDate = new Date(product.startDate);
      const startYear = startDate.getFullYear();
      const growthFactor = Math.pow(1 + (product.growth || 0) / 100, year - startYear);
      let monthlyQty = product.quantity;
      if (year === startYear) {
        const startMonth = startDate.getMonth();
        const monthsInYear = 12 - startMonth;
        monthlyQty = product.quantity * (monthsInYear / 12);
      }
      const annualQty = monthlyQty * 12 * growthFactor;
      yearQuantity += annualQty;
      yearRevenue += annualQty * product.price;
    });
    
    revenueByYear[year] = yearRevenue / 1000; // в тыс. руб.
    quantityByYear[year] = yearQuantity;
  });
  
  // Прямые затраты по годам
  let directCostsByYear = {};
  years.forEach(year => {
    let total = 0;
    products.forEach(product => {
      const productDirectCosts = directCosts.filter(c => c.product === product.product);
      const costPerUnit = productDirectCosts.reduce((sum, c) => sum + (c.amountPerUnit || 0), 0);
      const quantity = quantityByYear[year] * (product.quantity / products.reduce((s,p) => s + p.quantity, 0));
      total += costPerUnit * quantity;
    });
    directCostsByYear[year] = total / 1000;
  });
  
  // Косвенные затраты по годам
  let indirectCostsByYear = {};
  years.forEach(year => {
    let total = 0;
    indirectCosts.forEach(cost => {
      let annualAmount = cost.amount;
      if (cost.periodicity === 'ежемесячно') annualAmount *= 12;
      if (cost.periodicity === 'ежеквартально') annualAmount *= 4;
      if (cost.periodicity === 'раз в год') annualAmount *= 1;
      
      const growthFactor = Math.pow(1 + (cost.growth || 0) / 100, year - 2026);
      total += annualAmount * growthFactor;
    });
    indirectCostsByYear[year] = total / 1000;
  });
  
  // ФОТ по годам
  let payrollByYear = {};
  years.forEach(year => {
    let total = 0;
    personnel.forEach(person => {
      const hireDate = new Date(person.hireDate);
      const hireYear = hireDate.getFullYear();
      if (year >= hireYear && person.count > 0) {
        const growthFactor = Math.pow(1 + (person.growth || 0) / 100, year - hireYear);
        total += person.salary * person.count * 12 * growthFactor;
      }
    });
    payrollByYear[year] = total / 1000;
  });
  
  // Инвестиции по годам
  let investmentsByYear = {};
  years.forEach(year => {
    let total = 0;
    investments.forEach(inv => {
      const invDate = new Date(inv.date);
      if (invDate.getFullYear() === year) {
        total += inv.amount;
      }
    });
    investmentsByYear[year] = total / 1000;
  });
  
  // Итоговые строки
  const ebitda = {};
  const netProfit = {};
  let cashCumulative = {};
  let cashFlow = {};
  let cumulative = 0;
  
  years.forEach(year => {
    const revenue = revenueByYear[year] || 0;
    const direct = directCostsByYear[year] || 0;
    const indirect = indirectCostsByYear[year] || 0;
    const admin = 0; // Упрощённо
    const payroll = payrollByYear[year] || 0;
    const investments = investmentsByYear[year] || 0;
    
    ebitda[year] = revenue - direct - indirect - admin - payroll;
    netProfit[year] = ebitda[year] * 0.8; // упрощённый налог
    cashFlow[year] = netProfit[year] - investments;
    cumulative += cashFlow[year];
    cashCumulative[year] = cumulative;
  });
  
  // NPV (упрощённо)
  const discountRate = 0.16;
  let npv = 0;
  years.forEach((year, idx) => {
    npv += cashFlow[year] / Math.pow(1 + discountRate, idx + 1);
  });
  
  res.json({
    years,
    revenue: years.map(y => revenueByYear[y]),
    quantity: years.map(y => quantityByYear[y]),
    directCosts: years.map(y => directCostsByYear[y]),
    indirectCosts: years.map(y => indirectCostsByYear[y]),
    payroll: years.map(y => payrollByYear[y]),
    investments: years.map(y => investmentsByYear[y]),
    ebitda: years.map(y => ebitda[y]),
    netProfit: years.map(y => netProfit[y]),
    cashCumulative: years.map(y => cashCumulative[y]),
    npv: npv.toFixed(0),
    irr: -2.1,
    pi: (npv / 1000).toFixed(2),
    paybackPeriod: ">6 лет"
  });
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});